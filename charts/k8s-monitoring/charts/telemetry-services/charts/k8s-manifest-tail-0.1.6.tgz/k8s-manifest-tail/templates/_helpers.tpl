{{/*
Expand the name of the chart.
*/}}
{{- define "k8s-manifest-tail.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "k8s-manifest-tail.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "k8s-manifest-tail.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{ include "k8s-manifest-tail.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "k8s-manifest-tail.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k8s-manifest-tail.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name
*/}}
{{- define "k8s-manifest-tail.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "k8s-manifest-tail.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image reference
*/}}
{{- define "k8s-manifest-tail.image" -}}
{{- $registry := .Values.global.image.registry | default .Values.image.registry }}
{{- if .Values.image.digest }}
{{- printf "%s/%s@%s" $registry .Values.image.repository .Values.image.digest }}
{{- else }}
{{- $tag := .Values.image.tag | default .Chart.AppVersion }}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag }}
{{- end }}
{{- end }}

{{/*
Pluralize a Kubernetes kind name to its resource name.
Handles: Ingress->ingresses, Policy->policies, Pod->pods, etc.
*/}}
{{- define "k8s-manifest-tail.pluralize" -}}
{{- $kind := lower . }}
{{- if hasSuffix "ss" $kind }}
{{- printf "%ses" $kind }}
{{- else if hasSuffix "s" $kind }}
{{- $kind }}
{{- else if or (hasSuffix "ch" $kind) (hasSuffix "sh" $kind) (hasSuffix "x" $kind) (hasSuffix "z" $kind) }}
{{- printf "%ses" $kind }}
{{- else if hasSuffix "y" $kind }}
  {{- $stem := trimSuffix "y" $kind }}
  {{- if or (hasSuffix "a" $stem) (hasSuffix "e" $stem) (hasSuffix "i" $stem) (hasSuffix "o" $stem) (hasSuffix "u" $stem) }}
  {{- printf "%ss" $kind }}
  {{- else }}
  {{- printf "%sies" $stem }}
  {{- end }}
{{- else }}
{{- printf "%ss" $kind }}
{{- end }}
{{- end }}

{{/*
Image pull secrets. Merges global and chart-level pull secrets.
Each entry may be a bare string or a LocalObjectReference map ({name: foo}).
*/}}
{{- define "k8s-manifest-tail.imagePullSecrets" -}}
{{- $secrets := concat (.Values.global.image.pullSecrets | default (list)) (.Values.image.pullSecrets | default (list)) }}
{{- if $secrets }}
imagePullSecrets:
  {{- range $secrets }}
  {{- if kindIs "map" . }}
  - {{ toYaml . | trim }}
  {{- else }}
  - name: {{ . }}
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}
