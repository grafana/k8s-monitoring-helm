<!--
(NOTE: Do not edit README.md directly. It is a generated file!)
(      To make changes, please modify README.md.gotmpl and run `helm-docs`)
-->

# alloy-operator

![Version: 0.9.4](https://img.shields.io/badge/Version-0.9.4-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.14.4](https://img.shields.io/badge/AppVersion-1.14.4-informational?style=flat-square)

Grafana Alloy Operator, providing innovative ways for creating instances of Grafana Alloy.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| petewall | <pete.wall@grafana.com> |  |
| TylerHelmuth | <tyler.helmuth@grafana.com> |  |

<!-- markdownlint-disable no-bare-urls -->
<!-- markdownlint-disable list-marker-space -->
## Source Code

* <https://github.com/grafana/alloy-operator>
<!-- markdownlint-enable list-marker-space -->

## Requirements

| Repository | Name | Version |
|------------|------|---------|
|  | podlogs-crd | 0.0.0 |
| https://grafana.github.io/helm-charts | alloy-crd | 1.0.1 |
<!-- markdownlint-enable no-bare-urls -->

## Values

### Pod Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Set the affinity for the Alloy Operator pods. |
| nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Set the node selector for the Alloy Operator pods. |
| podAnnotations | object | `{}` | Additional annotations to add to the Alloy Operator pods. |
| podDisruptionBudget | object | `{}` | Configure a PodDisruptionBudget for the Alloy Operator pods. |
| podLabels | object | `{}` | Additional labels to add to the Alloy Operator pods. |
| podSecurityContext | object | `{"runAsNonRoot":true}` | Set the security context for the Alloy Operator pods. |
| priorityClassName | string | `""` | Sets the priority class name for the Alloy Operator pods. |
| tolerations | list | `[]` | Set the tolerations for the Alloy Operator pods. |
| topologySpreadConstraints | list | `[]` | Set the topology spread constraints for the Alloy Operator pods. |

### CRDs

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| crds.deployAlloyCRD | bool | `true` | Should this chart deploy the Alloy CRD? |
| crds.deployPodLogsCRD | bool | `false` | Should this chart deploy the PodLogs CRD? |

### Operator Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| extraArgs | list | `[]` | Additional arguments to pass to the Alloy Operator. |

### Deployment Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fullnameOverride | string | `""` | Overrides the chart's computed fullname. Used to change the full prefix of resource names. |
| global.namespaceOverride | string | `""` | Global namespace override. When set, all resources will be deployed to this namespace instead of the Helm release namespace. Takes lower precedence than `namespaceOverride`. |
| nameOverride | string | `""` | Overrides the chart's name. Used to change the infix in the resource names. |
| namespaceOverride | string | `""` | Overrides the namespace for all resources deployed by this chart. When empty, resources are deployed to the Helm release namespace. |
| replicaCount | int | `1` | How many replicas to use for the Alloy Operator Deployment. |

### Image Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.image.pullPolicy | string | `""` | Global image pull policy override. |
| global.image.pullSecrets | list | `[]` | Global image pull secrets. |
| global.image.registry | string | `""` | Global image registry override. |
| global.imagePullPolicy | string | `""` | Global image pull policy override. Takes lower precedence than `global.image.pullPolicy`. |
| global.imageRegistry | string | `""` | Global image registry override. Takes lower precedence than `global.image.registry`. |
| image.digest | string | `""` | Alloy Operator image digest. If set, will override the tag. Format: sha256:&lt;digest&gt;. |
| image.pullPolicy | string | `"IfNotPresent"` | The pull policy for images. |
| image.pullSecrets | list | `[]` | Optional set of image pull secrets. |
| image.registry | string | `"ghcr.io"` | Alloy Operator image registry |
| image.repository | string | `"grafana/alloy-operator"` | Alloy Operator image repository |
| image.tag | string | `""` | Alloy Operator image tag. When empty, the Chart's appVersion is used. |

### Leader Election Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| leaderElection.enabled | bool | `true` | Whether to enable leader election for the Alloy Operator. This is important when using multiple replicas or when rolling updates. If set to false, you risk having split-brain scenarios where multiple instances of the Alloy Operator try to manage the same Alloy instances. |

### Probes

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| livenessProbe | object | `{"initialDelaySeconds":15,"periodSeconds":20}` | Liveness probe settings |
| readinessProbe | object | `{"initialDelaySeconds":5,"periodSeconds":10}` | Readiness probe settings |

### Alloy Management Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| namespaces | list | `[]` | Restrict the Alloy Operator to only manage Alloy instances in the given list of namespaces. |
| ownNamespaceOnly | bool | `false` | Restrict the Alloy Operator to its own namespace only. Overrides the `namespaces` setting. |

### RBAC Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| rbac.create | bool | `true` | Whether to create the necessary RBAC resources for the Alloy Operator. |
| rbac.createClusterRoles | bool | `true` | Create ClusterRoles for the Alloy Operator. If set to false, only Roles and RoleBindings will be created. This setting requires the use of `namespaces` or `ownNamespaceOnly` to be set. |

### Resources

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| resources.limits | object | `{}` | Set the resource limits for the Alloy Operator pods. |
| resources.requests | object | `{}` | Set the resource requests for the Alloy Operator pods. |

### Container Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Set the security context for the operator container. |

### Service

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| service.health.port | int | `8081` | The port number for the health probes. |
| service.metrics.port | int | `8082` | The port number for the metrics service. |
| service.type | string | `"ClusterIP"` | The type of service to create for the operator. |

### Service Account Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.automount | bool | `true` | Whether the Alloy Operator pod should automatically mount the service account token. |
| serviceAccount.create | bool | `true` | Whether to create a service account for the Alloy Operator deployment. |
| serviceAccount.labels | object | `{}` | Additional labels to add to the service account |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |

### Service Monitor

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceMonitor.additionalLabels | object | `{}` | Set of labels to transfer from the Kubernetes Service onto the target |
| serviceMonitor.enabled | bool | `false` | Whether to create a ServiceMonitor |
| serviceMonitor.interval | string | `"60s"` | Set how frequently Prometheus should scrape |
| serviceMonitor.metricRelabelings | list | `[]` | Set ServiceMonitor metricRelabelings to apply to metrics after scraping. |
| serviceMonitor.relabelings | list | `[]` | Set ServiceMonitor relabelings to apply before scraping. |
| serviceMonitor.scrapeTimeout | string | `"10s"` | Set timeout for scrape |
| serviceMonitor.targetLabels | list | `[]` | Set of labels to transfer from the Kubernetes Service onto the target |
| serviceMonitor.telemetryPath | string | `"/metrics"` | Set path to metrics path |
